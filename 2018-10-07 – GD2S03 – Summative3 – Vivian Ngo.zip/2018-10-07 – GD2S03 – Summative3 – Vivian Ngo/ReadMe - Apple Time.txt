Apple time - ReadMe - Vivian Ngo

Controls/Instructions:
	- Tap anywhere on screen for fox to jump over rocks
	- Collect as many apples as you can
	- (Hard Level) Avoid flying rocks
	
Things implemented:
	- All characters (SK labels sprites shapes and tile nodes)
		- note: Tile map is visible in main menu on the right side of the screen,
				(The two rows of apple + rock stacks)
	- Actions
	- Physics + Physics contact delegate
		- Objects detect collision through physics
		- SKFieldNode
			- Radial gravity field exists in EASY mode
			- Position at player position and pulls a butterfly that constantly floats around the player
	- Transition
		- Occurs when changing into different scenes
	- Camera views scene while background physically moves
	- Audio 
		- Sound effects when jumping, collecting apples and hitting rocks
		- BGM continuously plays in game scene
	- Light
		- Light exists in menu as a sun :D
	- Particles
		- Heart particles spawn when player picks up an apple
		- Ouch particles spawn when player hits a rock
	- Touch events
		- UIResponder 
			- When buttons are tapped and when player taps for fox to jump
		- UIGestureRecognizer
			- Removed swiping because I was told it wasn't needed
			- I could have kept the swiping in but it lagged a lot on the IPhoneX emulator, even though it was okay on different emulators.
			
			
Levels
	- Easy level
		- Has still rocks to jump over
	- Hard Level
		- Has moving rocks to jump over / duck under (ducking is just staying still)
		
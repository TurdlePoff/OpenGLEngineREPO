//
//  GameScene.swift
//  18-09-01-Summative2-Vivian_Ngo
//
//  Created by Vivian Ngo on 3/09/18.
//
// MainMenu - Handles all main menu objects and input
//
//  Copyright © 2018 Vivian Ngo. All rights reserved.
//

import SpriteKit
import GameplayKit


class InstructionsScene: SKScene {
    
    let cs = GameElements();
    var goBack = SKShapeNode();
    var recordScore = SKLabelNode();
    
    override func didMove(to view: SKView) {
        
        self.addChild(cs.createIdleBackground(filename: "instructions",
                  position : CGPoint(x: self.frame.midX, y: self.frame.midY),
                  size: CGSize(width: self.frame.width, height: self.frame.height)))
            
        //Create title of game and set in logo
        addChild(cs.createText(text : "INSTRUCTIONS",
                   lines : 1,
                   fontSize : 32.0,
                   color : ColourVals.DARKGREEN.value,
                   fontName : "Helvetica",
                   point : CGPoint(x: self.frame.midX, y: self.frame.height - 100)));
        
        
        //Transparent go button that starts the game
        goBack = cs.createButton(UIColor.red,
                   CGSize(width: self.frame.width, height: self.frame.height),
                   CGPoint(x: self.frame.width - self.frame.midX/2, y: self.frame.midY),
                   transparency: 0.0);
        addChild(goBack);
        
        addChild(cs.createText(text : "Tap anywhere to return to menu",
                   lines : 1,
                   fontSize : 18.0,
                   color : UIColor.white,
                   fontName : "Helvetica",
                   point : CGPoint(x: self.frame.midX, y: 30)));
        
    }
    
    
    /******************************************************
     * touchesBegan: Starts game when go button is pressed
     * @parameter: touches & event - UITouch event parameters
     ******************************************************/
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        let location = touches.first?.location(in: self)
        
        if goBack.contains(location!)
        {
            let newScene = MainMenu(size: (self.view?.bounds.size)!);
            let transition = SKTransition.crossFade(withDuration: 2);
            self.view?.presentScene(newScene, transition: transition)
            transition.pausesOutgoingScene = true;
            transition.pausesIncomingScene = false;
        }
    }
}

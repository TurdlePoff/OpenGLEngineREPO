//
//  GameScene.swift
//  18-09-01-Summative2-Vivian_Ngo
//
//  Created by Vivian Ngo on 3/09/18.
//
//  GameScene - Handles the gameplay, all objects and input
//
//  Copyright © 2018 Vivian Ngo. All rights reserved.
//

import SpriteKit
import GameplayKit



class HardScene: SKScene, SKPhysicsContactDelegate {
    
    let cs = GameElements();
    var obstacle = SKSpriteNode();
    
    var scoreText = SKLabelNode();
    var highScoreText = SKLabelNode();
    
    var escapeButton = SKSpriteNode();
    var fox = SKSpriteNode();
    var ballColour: ColourVals = ColourVals.BLUE;
    var checkBall: Bool = false;
    var burst: Bool = true;
    var generatingPickup: Bool = false;
    var holdButton = SKShapeNode();
    
    var roundScore: Int = 0;
    
    var targetPoint = CGPoint();
    var foxRunAnimated : SKAction!;
    var foxJumpAnimated : SKAction!;
    var inAir : Bool = false;
    var jumpAction : SKAction!;
    
    //Background
    let backgrounds: [String] = ["blue_grass", "blue_grass", "blue_grass"];
    var back1: SKSpriteNode!
    var back2: SKSpriteNode!
    var back3: SKSpriteNode!
    var origBgPos = CGPoint();
    
    //Camera
    var cameraNode: SKCameraNode!
    
    //Player
    var playerLifeArray :[SKSpriteNode] = [];
    
    //Category bitmask for collisions
    enum CategoryBitMask
    {
        static let player: UInt32 = 1;
        static let pickup: UInt32 = 2;
        static let collide: UInt32 = 3;
    }
    
    override func didMove(to view: SKView) {
        self.physicsWorld.contactDelegate = self;
        //view.showsPhysics = true
        
        origBgPos = CGPoint(x: self.frame.midX, y: self.frame.midY);
        cameraNode = cs.createCamera(origBgPos);
        self.camera = cameraNode;
        createBackground();
        
        //Set original player positions target points
        player.originalPos = CGPoint(x: self.frame.midX/2/2, y: self.frame.midY - self.frame.midY/2 + 10);
        player.jumpedPos = self.frame.midY - self.frame.midY/2+120;
        targetPoint = CGPoint(x:-50, y: self.frame.midY + self.frame.midY/2);
        
        //Record score of game
        addChild(cs.createText(text : "Apple Record: " + String(player.recordScore),
                               lines : 1,
                               fontSize : 18.0,
                               color : ColourVals.PINK.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.width - 100, y: self.frame.height - 50)));
        
        //Highest score of current game session
        highScoreText = cs.createText(text : "Current Highest: " + String(player.highScore),
                                      lines : 1,
                                      fontSize : 18.0,
                                      color : ColourVals.PINK.value,
                                      fontName : "Helvetica",
                                      point : CGPoint(x: 125, y: self.frame.height-50));
        addChild(highScoreText);
        
        //Score text displaying the player's current score
        scoreText = cs.createText(text : "0",
                                  lines : 2,
                                  fontSize : 40.0,
                                  color : ColourVals.RED.value,
                                  fontName : "Helvetica",
                                  point : CGPoint(x: self.frame.midX, y: self.frame.midY + self.frame.midY/2 - 50));
        
        addChild(scoreText)
        
        //Gameplay jump button
        holdButton = cs.createButton(UIColor.white,
                                     CGSize(width: self.frame.width, height: self.frame.height),
                                     CGPoint(x: self.frame.midX, y: self.frame.midY),
                                     transparency: 0.0);
        
        addChild(holdButton);
        
        //Left transparent button for player to rotate wheel left
        escapeButton = cs.createSprite(spriteName: "returnButton",
                                       size: CGSize(width: 120, height: 30),
                                       pos: CGPoint(x: self.frame.width - 100, y: 30))
        addChild(escapeButton);
        
        //Create fox and random obstacles to start
        createPlayer();
        createRandomObstacle();
        
        //Player life UI - Displays player health
        playerLifeArray = cs.createPlayerLives(size: CGSize(width: 30.0, height: 30.0),
                                               position: CGPoint(x: 100.0, y: 40.0));
        
        playerLifeArray.forEach { life in
            addChild(life);
        }
        
        //Life text
        addChild(cs.createText(text : "Lives",
                               lines : 1,
                               fontSize : 14.0,
                               color : UIColor.white,
                               fontName : "Helvetica",
                               point : CGPoint(x: 50.0, y: 35.0)));
        
            //Didnt add light in main scenes as it lagged the game like crazy on the simulator
        //        addChild(cs.createLight(position: CGPoint(x: 50, y: self.frame.height-50)));
        //
        //        addChild(cs.createSun(position: CGPoint(x: 50, y: self.frame.height-50)));
    }
    
    /******************************************************
     * createPlayer: Creates a fox player with a physics body and animation
     ******************************************************/
    func createPlayer()
    {
        //Create fox sprite
        foxRunAnimated = cs.createFoxRunAnimation();
        foxJumpAnimated = cs.createFoxJumpAnimation();
        fox = SKSpriteNode();
        fox.name = "fox";
        fox.size = CGSize(width: 130.0, height: 100.0)
        fox.position = player.originalPos
        fox.physicsBody = SKPhysicsBody(circleOfRadius: 20.0, center: CGPoint(x: 25, y:0));
        fox.physicsBody?.isDynamic = true;
        fox.physicsBody?.categoryBitMask = CategoryBitMask.player;
        fox.physicsBody?.collisionBitMask = CategoryBitMask.player;
        fox.physicsBody?.contactTestBitMask = CategoryBitMask.collide;
        fox.physicsBody?.affectedByGravity = false;
        fox.run(SKAction.repeatForever(foxJumpAnimated), withKey: "foxJumpAnimated")
        fox.removeAction(forKey: "foxJumpAnimated")
        
        fox.run(SKAction.repeatForever(foxRunAnimated), withKey: "foxRunAnimated")
        addChild(fox);
    }
    
    /******************************************************
     * createPickup: Creates an apple pickup that destroys itself after six seconds
     ******************************************************/
    func createPickup()
    {
        //Create a ball shape node to use for the game
        let pickup = cs.createSprite(spriteName: "apple", size: CGSize(width: 20.0, height: 20.0),
                                     pos: CGPoint(x: self.frame.width + 50, y: self.frame.midY - self.frame.midY/2-13));
        let ballFall = SKAction.moveTo(x: targetPoint.x, duration: TimeInterval(player.obstacleSpeed))
        pickup.run(ballFall, withKey: "pickup")
        pickup.name = "pickup";
        pickup.physicsBody = SKPhysicsBody(circleOfRadius: 20.0);
        pickup.physicsBody?.isDynamic = false;
        pickup.physicsBody?.categoryBitMask = CategoryBitMask.pickup;
        pickup.physicsBody?.collisionBitMask = CategoryBitMask.pickup;
        pickup.physicsBody?.contactTestBitMask = CategoryBitMask.collide;
        pickup.physicsBody?.affectedByGravity = false;
        pickup.run(SKAction.sequence([
            SKAction.wait(forDuration: 6.0),
            SKAction.removeFromParent()
            ])
        )
        
        addChild(pickup);
    }
    
    /******************************************************
     * createRock: Creates a rock that moves up and down.
     * The player can jump over one and duck under the other.
     ******************************************************/
    func createRock()
    {
        //Create a ball shape node to use for the game
        let rock = cs.createSprite(spriteName: "rock04", size: CGSize(width: 50.0, height: 40.0),
                                   pos: CGPoint(x: self.frame.width + 50, y: self.frame.midY - self.frame.midY/2-10));
        let rockMove = SKAction.moveTo(x: targetPoint.x, duration: TimeInterval(player.obstacleSpeed))
        rock.run(rockMove, withKey: "rock")
        rock.name = "rock";
        rock.physicsBody = SKPhysicsBody(circleOfRadius: 20.0);
        rock.physicsBody?.isDynamic = false;
        rock.physicsBody?.categoryBitMask = CategoryBitMask.pickup;
        rock.physicsBody?.collisionBitMask = CategoryBitMask.pickup;
        rock.physicsBody?.contactTestBitMask = CategoryBitMask.collide;
        rock.physicsBody?.affectedByGravity = false;
        
        // jump up
        let enemyUpAction = SKAction.moveBy(x: 0, y: 150, duration: 1.2)
        
        // jump forward + land on ground
        let enemyDownAction = SKAction.moveBy(x: 0, y: -150, duration: 1.2)
        
        let i = (Int(arc4random_uniform(2) + 0));
        
        // sequence of move up, forward then down
        var enemySequence: SKAction?;
        
        //Spawn one of the two rock types
        if(i == 0)
        {
            //Spawn rock to duck under
            enemySequence = SKAction.sequence([enemyUpAction, enemyDownAction, enemyUpAction, enemyDownAction, enemyUpAction, enemyDownAction, enemyUpAction, enemyDownAction, enemyUpAction])
        }
        else
        {
            //Spawn rock to jump over
            let quickOffset = SKAction.moveBy(x: 0, y: -150, duration: 1.2)
            
            rock.position.y = self.frame.midY - self.frame.midY/2-10 + 150;
            enemySequence = SKAction.sequence([quickOffset, enemyUpAction, enemyDownAction, enemyUpAction, enemyDownAction, enemyUpAction, enemyDownAction, enemyUpAction])
        }
        
        //Delete the rock
        rock.run(SKAction.sequence([enemySequence!,
                                    SKAction.removeFromParent()
            ])
        )
        
        addChild(rock);
    }
    
    /******************************************************
     * createRandomObstacle: Creates either a pickup or a rock
     ******************************************************/
    func createRandomObstacle()
    {
        //Generate random obstable after random time
        if(!generatingPickup)
        {
            generatingPickup = true;
            let i = (Int(arc4random_uniform(2) + 0));
            
            if(i == 0)
            {
                createPickup();
            }
            else
            {
                createRock();
            }
            
            self.run(SKAction.wait(forDuration: 3.0, withRange: 3))
            {
                self.generatingPickup = false;
            }
        }
    }
    
    /******************************************************
     * createBackground: Creates 3 backgrounds for the scrolling
     ******************************************************/
    func createBackground()
    {
        back1 = SKSpriteNode(imageNamed: backgrounds[0]);
        back1.zPosition = -1;
        back1.name = "back1"
        back1.size = self.frame.size
        back1.position = origBgPos;
        back1.lightingBitMask = 1;
        back1.shadowCastBitMask = 0;
        back1.shadowedBitMask = 1;
        self.addChild(back1)
        
        back2 = SKSpriteNode(imageNamed: backgrounds[1]);
        back2.zPosition = -1;
        back2.name = "back2"
        back2.size = self.frame.size
        back2.position = CGPoint(x: back1.position.x + self.frame.maxX, y:back1.position.y)
        back2.lightingBitMask = 1;
        back2.shadowCastBitMask = 0;
        back2.shadowedBitMask = 1;
        self.addChild(back2)
        
        back3 = SKSpriteNode(imageNamed: backgrounds[2]);
        back3.zPosition = -1;
        back3.name = "back3"
        back3.size = self.frame.size
        back3.position = CGPoint(x:back1.position.x + self.frame.maxX+back2.size.width, y:back1.position.y)
        back3.lightingBitMask = 1;
        back3.shadowCastBitMask = 0;
        back3.shadowedBitMask = 1;
        self.addChild(back3)
    }
    
    
    /******************************************************
     * SpawnParticles: Spawns particles in that position
     * @parameter: node - node to spawn particles at
     ******************************************************/
    func SpawnParticles(node: SKNode, particleName: String) {
        if let magicParticles = SKEmitterNode(fileNamed: particleName) {
            magicParticles.position = node.position
            let emitterDuration = CGFloat(magicParticles.numParticlesToEmit) * magicParticles.particleLifetime
            let addEmitterAction = SKAction.run({self.addChild(magicParticles)})
            let wait = SKAction.wait(forDuration: TimeInterval(emitterDuration))
            
            let remove = SKAction.run({magicParticles.removeFromParent();})
            
            let sequence = SKAction.sequence([addEmitterAction, wait, remove])
            
            self.run(sequence)
        }
    }
    
    /******************************************************
     * didBegin: Detects all physics contacts between two objects
     ******************************************************/
    func didBegin(_ contact: SKPhysicsContact)
    {
        //        print("Contact");
        //        print(contact.bodyA.node?.name as Any );
        //        print(contact.bodyB.node?.name as Any );
        
        //If a fox comes into contact with a pickup
        if((contact.bodyA.node?.name == "fox" && contact.bodyB.node?.name == "pickup") ||
            (contact.bodyB.node?.name == "fox" && contact.bodyA.node?.name == "pickup"))
        {
            run(SKAction.playSoundFileNamed("collect3", waitForCompletion: true)) //play sound effect
            
            //Increase player score
            roundScore += 1;
            scoreText.text = String(roundScore);
            player.SetHighScore(score: roundScore);
            
            //If pickup comes into contact with the fox, spawn particle and then delete
            if(contact.bodyA.node?.name == "pickup")
            {
                SpawnParticles(node: contact.bodyA.node!, particleName: "MagicParticles");
                
                contact.bodyA.node?.removeFromParent();
            }
            else if(contact.bodyB.node?.name == "pickup")
            {
                SpawnParticles(node: contact.bodyB.node!, particleName: "MagicParticles");
                
                contact.bodyB.node?.removeFromParent();
            }
        }
        
        //If a fox comes into contact with a rock, remove player life and spawn particle
        if((contact.bodyA.node?.name == "fox" && contact.bodyB.node?.name == "rock") ||
            (contact.bodyB.node?.name == "fox" && contact.bodyA.node?.name == "rock"))
        {
            //Only injure player if they are invincible
            if(!player.playerInvincible)
            {
                player.playerInvincible = true;
                
                run(SKAction.playSoundFileNamed("hit1", waitForCompletion: true))
                
                if(contact.bodyA.node?.name == "rock")
                {
                    SpawnParticles(node: contact.bodyA.node!, particleName: "OuchParticles");
                    
                    contact.bodyA.node?.removeFromParent();
                }
                else if(contact.bodyB.node?.name == "rock")
                {
                    SpawnParticles(node: contact.bodyB.node!, particleName: "OuchParticles");
                    
                    contact.bodyB.node?.removeFromParent();
                }
                
                //RemoveLife
                if(player.playerLives != 0)
                {
                    player.playerLives -= 1;
                    playerLifeArray.last?.removeFromParent();
                    playerLifeArray.removeLast();
                }
                
                //allow 1 second cooldown after getting hit by a rock
                self.run(SKAction.wait(forDuration: TimeInterval(1)))
                {
                    player.playerInvincible = false;
                }
            }
        }
    }
    
    
    /******************************************************
     * touchesBegan: Handles wheel spinning in the game
     * @parameter: touches & event - UITouch event parameters
     ******************************************************/
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        let location = touches.first?.location(in: self)
        
        if escapeButton.contains(location!)
        {
            //Return to main menu
            let newScene = MainMenu(size: (self.view?.bounds.size)!);
            let transition = SKTransition.crossFade(withDuration: 2);
            self.view?.presentScene(newScene, transition: transition)
            transition.pausesOutgoingScene = true;
            transition.pausesIncomingScene = false;
        }
        
        if holdButton.contains(location!)
        {
            //If the player is not in the middle of jumping, allow jump
            if(!inAir)
            {
                inAir = true;
                
                run(SKAction.playSoundFileNamed("jump", waitForCompletion: true))
                fox.run(foxJumpAnimated, withKey: "foxJumpAnimated")
                
                // jump up
                let jumpUpAction = SKAction.moveBy(x: 50, y: 120, duration: 0.6)
                
                // jump forward + land on ground
                let jumpforwardAction = SKAction.moveBy(x: 50, y: -120, duration: 0.6)
                
                // jump down
                let jumpDownAction = SKAction.moveBy(x: -100, y:0, duration: 0.3)
                
                // sequence of move up, forward then down
                let jumpSequence = SKAction.sequence([jumpUpAction, jumpforwardAction, jumpDownAction])
                
                // make player jump sequence
                fox.run(jumpSequence) {
                    self.inAir = false;
                }
            }
        }
    }
    
    /******************************************************
     * update: Handles gamelogic
     * @parameter: currentTime - current time interval of machine
     ******************************************************/
    override func update(_ currentTime: TimeInterval) {
        if(player.playerLives <= 0)
        {
            player.SetFinalScore(score: player.currentScore);
            let newScene = GameOverScene(size: (self.view?.bounds.size)!);
            let transition = SKTransition.crossFade(withDuration: 2);
            self.view?.presentScene(newScene, transition: transition)
            transition.pausesOutgoingScene = true;
            transition.pausesIncomingScene = false;
        }
        
        //Background scroll
        if(!cameraNode.contains(back1) && back1.position.x < 0 - back1.frame.width)
        {
            back1.position.x += 3 * back1.frame.width;
            //            back3.position.x += 3 * back3.frame.width;
        }
        else if(!cameraNode.contains(back2) && back2.position.x < 0 - back2.frame.width)
        {
            back2.position.x += 3 * back2.frame.width;
        }
        else if(!cameraNode.contains(back3) && back3.position.x < 0 - back3.frame.width)
        {
            back3.position.x += 3 * back3.frame.width;
        }
        back1.position.x -= 7.8;
        back2.position.x -= 7.8;
        back3.position.x -= 7.8;
        
        //create obstacle
        if(!generatingPickup)
        {
            createRandomObstacle();
        }
        
        //Reset fox position if not jumping
        if(!inAir)
        {
            // set original player position just in case it becomes something funky
            fox.position = player.originalPos;
        }
        
        //If the ball is in the middle of the circle
        if(obstacle.position.x <= targetPoint.x && !checkBall)
        {
            checkBall = true;
            
            //If it comes into contact with the end of the screen
            obstacle.removeFromParent();
            createRandomObstacle()
            //Adjust ball properties
            //resetting player effects
            checkBall = false;
        }
        
        //Score
        highScoreText.text = "Current High Score: " + String(player.highScore);
    }
}

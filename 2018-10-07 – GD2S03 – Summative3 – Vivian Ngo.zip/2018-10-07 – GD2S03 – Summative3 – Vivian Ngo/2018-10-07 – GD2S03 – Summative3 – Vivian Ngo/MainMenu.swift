//
//  GameScene.swift
//  18-09-01-Summative2-Vivian_Ngo
//
//  Created by Vivian Ngo on 3/09/18.
//
// MainMenu - Handles all main menu objects and input
//
//  Copyright © 2018 Vivian Ngo. All rights reserved.
//

import SpriteKit
import GameplayKit


class MainMenu: SKScene {
    let cs = GameElements();
    var leftButton = SKSpriteNode();
    var rightButton = SKSpriteNode();

    var resetButton = SKSpriteNode();
    var instrButton = SKSpriteNode();
    var background = SKSpriteNode();
    var sun = SKSpriteNode();

    var recordScore = SKLabelNode();
    var highScore = SKLabelNode();
    var lastScore = SKLabelNode();

    override func didMove(to view: SKView) {
        
        background = cs.createIdleBackground(filename: "blue_grass",
             position : CGPoint(x: self.frame.midX, y: self.frame.midY),
             size: CGSize(width: self.frame.width, height: self.frame.height));
        background.zPosition = -2;
        background.lightingBitMask = 1;
        background.shadowCastBitMask = 0;
        background.shadowedBitMask = 1;

        addChild(background);
        
        
        //Create title of game and set in logo
        addChild(cs.createText(text : "APPLE TIME",
                               lines : 1,
                               fontSize : 32.0,
                               color : ColourVals.DARKGREEN.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX, y: self.frame.height - 100)));
        
        //Record score of game
        recordScore = cs.createText(text : "Apple Record: " + String(player.recordScore),
                               lines : 2,
                               fontSize : 30.0,
                               color : ColourVals.RED.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX, y: self.frame.midY+20));
        addChild(recordScore);
        
        //Highest score of current game session
        highScore = cs.createText(text : "Current highest: " + String(player.highScore),
                               lines : 2,
                               fontSize : 30.0,
                               color : ColourVals.PINK.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX, y: self.frame.midY-30));
        addChild(highScore);
        
        //go button that starts an easy game
        leftButton = cs.createSprite(spriteName: "roundButton", size: CGSize(width: 100, height: 100), pos: CGPoint(x: self.frame.midX/2-50, y: self.frame.midY+20));
        leftButton.zPosition = -1;

        addChild(leftButton);

        //go button that starts a hard game
        rightButton = cs.createSprite(spriteName: "roundButton", size: CGSize(width: 100, height: 100), pos: CGPoint(x: self.frame.width-self.frame.midX/2+50, y: self.frame.midY+20));
        rightButton.zPosition = -1;

        addChild(rightButton);

        //Create text for level buttons
        addChild(cs.createText(text : " EASY\nLEVEL",
                               lines : 2,
                               fontSize : 18.0,
                               color : UIColor.white,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX/2-50, y: self.frame.midY)));
        
        addChild(cs.createText(text : " HARD\nLEVEL",
                               lines : 2,
                               fontSize : 18.0,
                               color : UIColor.white,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.width-self.frame.midX/2+50, y: self.frame.midY)));
        
        //Create 'instructions'
        addChild(cs.createText(text : "Tap on a level button to start playing",
                               lines : 1,
                               fontSize : 18,
                               color : UIColor.white,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX, y: 30)));
        
        addChild(cs.createIdlePlayer(size: CGSize(width: 80.0, height: 80.0),
            position: CGPoint(x: self.frame.midX/2/2, y: self.frame.midY - self.frame.midY/2 + 10), fileName: "foxIdle1"));
        
        //resets the scores
        resetButton = cs.createSprite(spriteName: "resetButton",
                  size: CGSize(width: 120, height: 30),
                  pos: CGPoint(x: self.frame.width - 100, y: self.frame.height-30))
        addChild(resetButton);
        
        //resets the scores
        instrButton = cs.createSprite(spriteName: "instrButton",
                  size: CGSize(width: 150, height: 40),
                  pos: CGPoint(x: self.frame.midX, y: self.frame.midY-80))
        addChild(instrButton);
        
        addChild(cs.createLight(position: CGPoint(x: 50, y: self.frame.height-50)));
        
        addChild(cs.createSun(position: CGPoint(x: 50, y: self.frame.height-50)));
        
        initialiseTiles();
    }
    
    /******************************************************
     * initialiseTiles: Initialises tiles to add into main menu
     ******************************************************/
    func initialiseTiles()
    {
        let columns = 4;
        let rows = 1;
        let size = CGSize(width: 32, height: 32);
        
        let tileTexture = SKTexture(imageNamed: "rock04.png");
        let tileDefinition = SKTileDefinition(texture: tileTexture, size: size);
        let tileGroup = SKTileGroup(tileDefinition: tileDefinition);
        
        let appleTileTexture = SKTexture(imageNamed: "apple.png");
        let appleTileDefinition = SKTileDefinition(texture: appleTileTexture, size: size);
        let appleTileGroup = SKTileGroup(tileDefinition: appleTileDefinition);
        
        let tileSet = SKTileSet(tileGroups: [tileGroup]);
        let tileMapNode = SKTileMapNode(tileSet: tileSet, columns: columns, rows: rows, tileSize:size);
        tileMapNode.position = CGPoint(x: self.frame.width - 200, y: self.frame.midY/2-10)
        
        let appleTileSet = SKTileSet(tileGroups: [appleTileGroup]);
        let appleTileMapNode = SKTileMapNode(tileSet: appleTileSet, columns: columns, rows: 2, tileSize:size);
        appleTileMapNode.position = CGPoint(x: self.frame.width - 200, y: self.frame.midY/2+10)
        
        tileMapNode.setTileGroup(tileGroup, forColumn: 0, row: 0)
        tileMapNode.setTileGroup(tileGroup, forColumn: 3, row: 0)
        
        appleTileMapNode.setTileGroup(appleTileGroup, forColumn: 1, row: 0)
        appleTileMapNode.setTileGroup(appleTileGroup, forColumn: 2, row: 0)
        appleTileMapNode.setTileGroup(appleTileGroup, forColumn: 0, row: 1)
        appleTileMapNode.setTileGroup(appleTileGroup, forColumn: 1, row: 1)
        appleTileMapNode.setTileGroup(appleTileGroup, forColumn: 2, row: 1)
        appleTileMapNode.setTileGroup(appleTileGroup, forColumn: 3, row: 1)

        self.addChild(tileMapNode);
        self.addChild(appleTileMapNode);

    }
    
    /******************************************************
     * touchesBegan: Starts game when go button is pressed
     * @parameter: touches & event - UITouch event parameters
     ******************************************************/
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        let location = touches.first?.location(in: self)
        
        if resetButton.contains(location!)
        {
            //Resets scores
            player.ResetScores();
            recordScore.text = "Apple Record: " + String(player.recordScore);
            highScore.text = "Current highest: " + String(player.highScore);
        }
        else if instrButton.contains(location!)
        {
            //instructions button
            let newScene = InstructionsScene(size: (self.view?.bounds.size)!);
            let transition = SKTransition.crossFade(withDuration: 2);
            self.view?.presentScene(newScene, transition: transition)
            transition.pausesOutgoingScene = true;
            transition.pausesIncomingScene = false;
        }
        else if leftButton.contains(location!)
        {
            //starts easy level
            player.Reset();
            let newScene = GameScene(size: (self.view?.bounds.size)!);
            let transition = SKTransition.crossFade(withDuration: 2);
            self.view?.presentScene(newScene, transition: transition)
            transition.pausesOutgoingScene = true;
            transition.pausesIncomingScene = false;
        }
        else if rightButton.contains(location!)
        {
            //starts hard level
            player.Reset();
            let newScene = HardScene(size: (self.view?.bounds.size)!);
            let transition = SKTransition.crossFade(withDuration: 2);
            self.view?.presentScene(newScene, transition: transition)
            transition.pausesOutgoingScene = true;
            transition.pausesIncomingScene = false;
        }
    }
}

//
//  File.swift
//  18-09-01-Summative2-Vivian_Ngo
//
//  Created by Vivian Ngo on 1/10/18.
//  Copyright © 2018 Vivian Ngo. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit

//ColourValEnum with self specified colours
enum ColourVals: Int
{
    case BLUE = 0
    case RED
    case YELLOW
    case GREEN
    case DARKBLUE
    case DARKGREEN
    case PINK

    var value: UIColor
    {
        switch self {
        case .BLUE:     return UIColor(red: 77/255.0, green: 157/255.0, blue: 210/255.0, alpha: 1.0)
        case .RED:      return UIColor(red: 210/255.0, green: 77/255.0, blue: 77/255.0, alpha: 1.0)
        case .YELLOW:   return UIColor(red: 255/255.0, green: 232/255.0, blue: 78/255.0, alpha: 1.0)
        case .GREEN:    return UIColor(red: 77/255.0, green: 210/255.0, blue: 102/255.0, alpha: 1.0)
        case .DARKBLUE: return UIColor(red: 13/255.0, green: 79/255.0, blue: 186/255.0, alpha: 1.0)
        case .DARKGREEN: return UIColor(red: 56/255.0, green: 183/255.0, blue: 63/255.0, alpha: 1.0)
        case .PINK: return UIColor(red: 240/255.0, green: 110/255.0, blue: 170/255.0, alpha: 1.0)
        }
    }
}

class GameElements
{
    /******************************************************
     * createSprite: Creates a SKLabelNode text object
     * @parameter: text - text to render
     * @parameter: lines - amount of lines of text to render
     * @parameter: fontSize - size to font
     * @parameter: color - color of the text
     * @parameter: fontName - name of the font
     * @parameter: point - position to render the text
     * @return: titleName - returns the SKLabel text
     ******************************************************/
    func createText(text : String, lines : Int, fontSize : CGFloat, color : UIColor, fontName : String, point : CGPoint)->SKLabelNode
    {
        var titleName: SKLabelNode!;
        titleName = SKLabelNode();
        titleName.numberOfLines = lines;
        titleName.text = text;
        titleName.fontSize = fontSize;
        titleName.fontName = fontName;
        titleName.fontColor = color;
        titleName.position = point;
        return titleName;
    }
    
    /******************************************************
     * createSprite: Creates an SKSpriteNode
     * @parameter: spriteName - name of the image to set the sprite
     * @parameter: sizeW - colour to set the shape
     * @parameter: sizeH - size to set the shape
     * @parameter: posX - position to set the shape
     * @parameter: posY - transparency to set the shape
     * @return: buttonShape - returns a button shape
     ******************************************************/
    func createSprite(spriteName : String, size : CGSize, pos : CGPoint)->SKSpriteNode
    {
        var newSpriteNode: SKSpriteNode!;
        
        newSpriteNode = SKSpriteNode(imageNamed: spriteName);
        newSpriteNode.size = size;
        newSpriteNode.anchorPoint = CGPoint(x: 0.5, y: 0.5);
        newSpriteNode.position = pos;
        
        return newSpriteNode;
    }
    
    /******************************************************
     * createBall: Creates an ball SKShapeNode
     * @parameter: colour - colour to set the shape
     * @parameter: pos - position to set the shape
     * @return: ballShape - returns a ball shape
     ******************************************************/
    func createBall(_ colour: ColourVals, _ pos: CGPoint)->SKShapeNode
    {
        var ballShape: SKShapeNode!;
        ballShape = SKShapeNode(circleOfRadius: 20.0);
        ballShape.position = CGPoint(x: pos.x, y: pos.y);//x: self.frame.midX, y: self.frame.midY);
        ballShape.fillColor = colour.value;
        ballShape.strokeColor = colour.value;
        ballShape.lineWidth = 2.0;
        
        return ballShape;
    }
    
    /******************************************************
     * createCamera: Creates a camera
     * @parameter: pos - position to set the camera
     * @return: cameraNode - the camera created
     ******************************************************/
    func createCamera(_ pos: CGPoint)->SKCameraNode
    {
        let cameraNode = SKCameraNode();
        cameraNode.setScale(1);
        cameraNode.position = CGPoint(x: pos.x, y: pos.y);
        return cameraNode;
    }
    
    /******************************************************
     * createButton: Creates an button SKShapeNode
     * @parameter: colour - colour to set the shape
     * @parameter: size - size to set the shape
     * @parameter: pos - position to set the shape
     * @parameter: tr - transparency to set the shape
     * @return: buttonShape - returns a button shape
     ******************************************************/
    func createButton(_ colour: UIColor, _ size: CGSize, _ pos: CGPoint, transparency tr: CGFloat)->SKShapeNode
    {
        var buttonShape: SKShapeNode!;
        buttonShape = SKShapeNode(rectOf: size);
        buttonShape.position = pos;
        buttonShape.fillColor = colour;
        buttonShape.lineWidth = 2.0;
        buttonShape.strokeColor = colour;
        buttonShape.alpha = tr;
        
        return buttonShape;
    }
    
    /******************************************************
     * RandColour: Returns a random ColourVals value
     * 0 - BLUE, 1 - RED, 2 - YELLOW, 3 - GREEN
     * @return: ColourVals value - A randomly generated colour
     ******************************************************/
    func RandColour() -> ColourVals
    {
        let i = (Int(arc4random_uniform(4) + 0));
        
        return ColourVals(rawValue: i)!;
    }
    
    /******************************************************
     * createBackgroundAudio: Creates a bgm given the audio filename
     * @parameter: fileName - name of the file to play
     * @parameter: looped - whether the track should be played once or looped
     ******************************************************/
    func createBackgroundAudio(_ fileName: String, _ looped: Bool) -> SKAudioNode
    {
        let audioNode = SKAudioNode(fileNamed: fileName);
        audioNode.autoplayLooped = looped;
        return audioNode;
    }
    
    /******************************************************
     * createSun: Creates a light source at the given position sprite
     * @parameter: position - position of the light
     ******************************************************/
    func createLight(position: CGPoint)->SKLightNode
    {
        let lightSource = SKLightNode();
        lightSource.categoryBitMask = 1;
        lightSource.falloff = 4;
        lightSource.ambientColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0);
        lightSource.lightColor = UIColor(red: 1.0, green: 1.0, blue: 0.0, alpha: 1.0);
        lightSource.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.8);
        lightSource.position = position;
        
        return lightSource;
    }
    
    /******************************************************
     * createSun: Creates a sun sprite
     * @return: a sun sprite
     ******************************************************/
    func createSun(position: CGPoint)->SKSpriteNode
    {
        let sun = createSprite(spriteName: "sunny", size: CGSize(width: 60, height: 60), pos: position)
        sun.lightingBitMask = 1;
        sun.shadowCastBitMask = 1;
        sun.shadowedBitMask = 1;
        
        return sun;
    }
    
    /******************************************************
     * createIdleBackground: Creates idle background
     * @parameter: position - position of background
     * @parameter: size - size of background
     * @return: ColourVals value - A randomly generated colour
     ******************************************************/
    func createIdleBackground(filename: String, position: CGPoint, size: CGSize) -> SKSpriteNode
    {
        let background = SKSpriteNode(imageNamed: filename);
        background.zPosition = -1;
        background.name = "bg";
        background.size = size;
        background.position = position;
        return background;
    }
    
    /******************************************************
     * createIdlePlayer: Creates idle player sprite
     * @parameter: position - position of background
     * @return: ColourVals value - A randomly generated colour
     ******************************************************/
    func createIdlePlayer(size: CGSize, position: CGPoint, fileName: String) -> SKSpriteNode
    {
        //Creates a plain fox sprite
        let fox = SKSpriteNode(imageNamed: fileName);
        fox.name = "fox";
        fox.size = size;//CGSize(width: 130.0, height: 130.0)
        fox.position = position;
        

        return fox;
    }
    
    /******************************************************
     * createIdlePlayer: Creates idle player sprite
     * @parameter: position - position of background
     * @return: ColourVals value - A randomly generated colour
     ******************************************************/
    func createPlayerLives(size: CGSize, position: CGPoint) -> [SKSpriteNode]
    {
        //Creates a plain fox sprite
        var lifeArray :[SKSpriteNode] = [SKSpriteNode]()

        lifeArray.append(createFoxIcon(size: size, position: position))
        lifeArray.append(createFoxIcon(size: size, position: CGPoint(x: position.x + 50.0, y: position.y)))
        lifeArray.append(createFoxIcon(size: size, position: CGPoint(x: position.x + 100.0, y: position.y)))

        return lifeArray;
    }
    
    /******************************************************
     * createFoxIcon: A fox icon
     ******************************************************/
    func createFoxIcon(size: CGSize, position: CGPoint)->SKSpriteNode
    {
        let foxLife = SKSpriteNode(imageNamed: "foxIcon");
        foxLife.name = "fox";
        foxLife.size = size;
        foxLife.position = position;
        return foxLife;
    }
    
    /******************************************************
     * createFoxRunAnimation: A fox running animation
     ******************************************************/
    func createFoxRunAnimation()->SKAction
    {
        let atlas = SKTextureAtlas(named: "FoxRun");
        var foxRunAnimated : SKAction!;
        foxRunAnimated = SKAction.animate(with: [atlas.textureNamed("fox5"),
                                                 atlas.textureNamed("fox4"),
                                                 atlas.textureNamed("fox3"),
                                                 atlas.textureNamed("fox2"),
                                                 atlas.textureNamed("fox1")], timePerFrame: 0.1)
        return foxRunAnimated;
    }
    
    /******************************************************
     * createFoxJumpAnimation: A fox jumping animation
     ******************************************************/
    func createFoxJumpAnimation()->SKAction
    {
        let atlas = SKTextureAtlas(named: "FoxJump");
        var foxJumpAnimated : SKAction!;
        foxJumpAnimated = SKAction.animate(with: [atlas.textureNamed("foxJump1"),
                                                  atlas.textureNamed("foxJump2"),
                                                  atlas.textureNamed("foxJump3"),
                                                  atlas.textureNamed("foxJump4"),
                                                  atlas.textureNamed("foxJump5")], timePerFrame: 0.2);
        return foxJumpAnimated;
    }
}

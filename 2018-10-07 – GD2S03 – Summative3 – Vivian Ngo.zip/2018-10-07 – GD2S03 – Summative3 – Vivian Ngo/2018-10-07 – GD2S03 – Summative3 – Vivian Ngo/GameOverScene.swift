//
//  GameScene.swift
//  18-09-01-Summative2-Vivian_Ngo
//
//  Created by Vivian Ngo on 3/09/18.
//
//  GameScene - Handles the gameplay, all objects and input
//
//  Copyright © 2018 Vivian Ngo. All rights reserved.
//

import SpriteKit
import GameplayKit



class GameOverScene: SKScene {
    
    let cs = GameElements();
    
    var holdButton = SKShapeNode();

    var roundScore: Int = 0;
    
    
    override func didMove(to view: SKView) {
       
        addChild(cs.createIdleBackground(filename: "blue_grass",
            position : CGPoint(x: self.frame.midX, y: self.frame.midY),
            size: CGSize(width: self.frame.width, height: self.frame.height)))
        
        if(player.newRecord)
        {
            addChild(cs.createText(text : "New Record",
                                   lines : 1,
                                   fontSize : 12.0,
                                   color : ColourVals.RED.value,
                                   fontName : "Helvetica",
                                   point : CGPoint(x: self.frame.width - 100, y: self.frame.midY+20)));
        }
        
        //Record score of game
        addChild(cs.createText(text : "Record Score: " + String(player.recordScore),
                               lines : 1,
                               fontSize : 18.0,
                               color : ColourVals.PINK.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.width - 110, y: self.frame.midY)));
        
        //Highest score of current game session
//        highScoreText =
        addChild(cs.createText(text : "Current Highest: " + String(player.highScore),
                               lines : 1,
                               fontSize : 18.0,
                               color : ColourVals.PINK.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: 125, y: self.frame.midY)));
        
        addChild(cs.createText(text : "Apples Obtained: " + String(player.currentScore),
                               lines : 1,
                               fontSize : 24.0,
                               color : ColourVals.RED.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX, y: self.frame.midY+50)));
        
        addChild(cs.createText(text : "Tap anywhere to return to main menu",
                               lines : 1,
                               fontSize : 18,
                               color : UIColor.white,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX, y: 30)));
        
        //Create title of game and set in logo
        addChild(cs.createText(text : "GAMEOVER",
                               lines : 1,
                               fontSize : 32.0,
                               color : ColourVals.DARKGREEN.value,
                               fontName : "Helvetica",
                               point : CGPoint(x: self.frame.midX, y: self.frame.height - 100)));
        
        //Transparent button to handle player tap
        holdButton = cs.createButton(UIColor.white,
                                     CGSize(width: self.frame.width, height: self.frame.height),
                                     CGPoint(x: self.frame.midX, y: self.frame.midY),
                                     transparency: 0.0);
        addChild(holdButton);
        
        addChild(cs.createIdlePlayer(size: CGSize(width: 130.0, height: 130.0),
            position: CGPoint(x: self.frame.midX, y: self.frame.midY - self.frame.midY/2 + 15), fileName: "foxIdle"));
    }
    
    /******************************************************
     * touchesBegan: Handles wheel spinning in the game
     * @parameter: touches & event - UITouch event parameters
     ******************************************************/
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        let location = touches.first?.location(in: self)
        
        //Return to main menu
        if holdButton.contains(location!)
        {
            let newScene = MainMenu(size: (self.view?.bounds.size)!);
            let transition = SKTransition.crossFade(withDuration: 2);
            self.view?.presentScene(newScene, transition: transition)
            transition.pausesOutgoingScene = true;
            transition.pausesIncomingScene = false;
        }
    }
    
    /******************************************************
     * update: Handles gamelogic
     * @parameter: currentTime - current time interval of machine
     ******************************************************/
    override func update(_ currentTime: TimeInterval) {
        
    }
    
}

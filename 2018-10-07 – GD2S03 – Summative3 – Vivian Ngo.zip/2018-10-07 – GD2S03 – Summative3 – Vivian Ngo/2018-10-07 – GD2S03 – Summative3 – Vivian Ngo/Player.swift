//
//  Player.swift
//  18-09-01-Summative2-Vivian_Ngo
//
//  Created by Vivian Ngo on 2/10/18.
//
//  Player - Handles player values
//
//  Copyright © 2018 Vivian Ngo. All rights reserved.
//

import Foundation
import GameplayKit

class Player
{
    var currentColour:ColourVals = ColourVals.BLUE;
    var currentScore: Int = 0;
    var highScore: Int;
    var recordScore: Int;
    var obstacleSpeed: CGFloat = 6.0;
    var continueGame: Bool;
    var playerLives: Int = 3;
    var playerInvincible: Bool = false;
    var newRecord: Bool = false;

    var originalPos = CGPoint(x: 0.0, y: 0.0)
    var jumpedPos: CGFloat = 0.0;

    let defaults = UserDefaults.standard;
    
    init() {
        recordScore = defaults.integer(forKey: "RecordScore")
        highScore = 0;
        continueGame = true;
    }
    
    /******************************************************
     * Reset: resets player values
     ******************************************************/
    func Reset()
    {
        currentColour = ColourVals.BLUE;
        obstacleSpeed = 5.0;
        playerLives = 3;
        continueGame = true;
        playerInvincible = false;
        newRecord = false;
    }
    
    /******************************************************
     * SetHighScore: set high score
     * @parameter: _score - score obtained from the game round
     ******************************************************/
    func SetHighScore(score _score: Int)
    {
        currentScore = _score;
        if(currentScore > highScore)
        {
            highScore = currentScore;
        }
    }
    
    /******************************************************
     * SetScore: player score
     * @parameter: _score - score obtained from the game round
     ******************************************************/
    func SetFinalScore(score _score: Int)
    {
        currentScore = _score;
        if(currentScore >= highScore)
        {
            highScore = currentScore;
            if(highScore >= recordScore)
            {
                newRecord = true;
                recordScore = highScore;
                defaults.set(recordScore, forKey: "RecordScore");
            }
        }
    }
    
    /******************************************************
     * ResetScores: resets player scores
     * @parameter: _score - score obtained from the game round
     ******************************************************/
    func ResetScores()
    {
        currentScore = 0;
        highScore = 0;
        recordScore = 0;
        defaults.set(0, forKey: "RecordScore");
    }
}

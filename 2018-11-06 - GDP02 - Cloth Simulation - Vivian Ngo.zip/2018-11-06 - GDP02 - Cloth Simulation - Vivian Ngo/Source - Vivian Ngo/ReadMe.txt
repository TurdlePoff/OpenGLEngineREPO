Controls:

**Ball Controls**
	W - forwards
	S - backwards
	A - left
	D - right
	Q - up
	E - down
	
**Wind Controls**
	W - forward wind 
	S - backward wind 
	A - left wind 
	D - right wind 
	Q - up wind
	E - down wind

**Camera Controls**
	Please hold down the middle mouse 
			SCROLL button
	to rotate the camera view + move with the following controls:
	U - forwards
	J - backwards
	H - left
	K - right
	
**Curtain controls**
	Z - Squish curtain
	X - Expand curtain

R - Reset
T - Unpin all pins/Drop cloth
B - Toggle ball movement and wind movement
F - Delete random constraint
